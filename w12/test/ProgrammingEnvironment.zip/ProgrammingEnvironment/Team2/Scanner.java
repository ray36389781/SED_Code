public class Scanner {
    public void process() {
        System.out.println("Scanning.....");
    }
}
