public class ProgramNode {
    public void process() {
        System.out.println("Construct Program Node");
    }
}
