public class Main {
    public static Subsystem compilerSubsystem = new CompilerSubsystem();
	public static void main (String args[]) {
        	compilerSubsystem.process();
	}
}
