public class Main {
    private static CompilerSubsystem compilerSubsystem = new CompilerSubsystem();
	public static void main (String args[]) {
        	compilerSubsystem.compile();
	}
}
