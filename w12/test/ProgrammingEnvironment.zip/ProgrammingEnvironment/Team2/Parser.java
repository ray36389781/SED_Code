public class Parser {
    public void process() {
        System.out.println("Parsing.....");
    }
}
