public abstract class Subsystem {
    abstract public void process();
}
