public class BytecodeStream {
    public void process() {
        System.out.println("Output bytecode.....");
    }
}
