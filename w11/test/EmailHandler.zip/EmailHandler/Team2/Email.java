public class Email {
    String type;
    public Email (String type) {
        this.type = type;
    }
}
